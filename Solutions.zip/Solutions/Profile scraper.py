import os
import requests
from bs4 import BeautifulSoup
import pandas as pd

# Define the URL for the page with the data
url = input("URL: ")
response = requests.get(url)
soup = BeautifulSoup(response.content, 'html.parser')

# Data dictionary to store scraped information
data = {
    'Hunter Name': [],  # Hunter Name should be first
    'Impact Score': [],
    'Reports': [],
    'Points': [],
    'Rank': [],
    'Contact URL': [],
    'Contact Name': []
}

# Scrape Hunter Name
hunter_name_div = soup.find('div', class_='hunter-name')
if hunter_name_div:
    span_tag = hunter_name_div.find('span')
    if span_tag:
        hunter_name = span_tag.text.strip()
        data['Hunter Name'].append(hunter_name)
    else:
        data['Hunter Name'].append("Not found")
else:
    data['Hunter Name'].append("Not found")

# Scrape Impact Score
impact = soup.find('div', class_='metric', id='impact')
if impact:
    impact_value = impact.find('span', class_='value').get_text().strip()
    data['Impact Score'].append(impact_value)
else:
    data['Impact Score'].append("Not found")

# Scrape Reports
reports = soup.find('div', class_='metric', id='reports')
if reports:
    reports_value = reports.find('span', class_='value').get_text().strip()
    data['Reports'].append(reports_value)
else:
    data['Reports'].append("Not found")

# Scrape Points
points = soup.find('div', class_='metric', id='points')
if points:
    points_value = points.find('span', class_='value').get_text().strip()
    data['Points'].append(points_value)
else:
    data['Points'].append("Not found")

# Scrape Rank
rank = soup.find('div', class_='metric', id='rank')
if rank:
    rank_value = rank.find('span', class_='value').get_text().strip()
    data['Rank'].append(rank_value)
else:
    data['Rank'].append("Not found")

# Scrape Contact (Social Media Link)
social_network_div = soup.find('div', class_='social-network-link-list')
if social_network_div:
    social_link = social_network_div.find('a', href=True)
    if social_link:
        contact_url = social_link['href']
        contact_name = social_link.get_text(strip=True)
        data['Contact URL'].append(contact_url)
        data['Contact Name'].append(contact_name)
    else:
        data['Contact URL'].append("Not found")
        data['Contact Name'].append("Not found")
else:
    data['Contact URL'].append("Not found")
    data['Contact Name'].append("Not found")

# Convert the data dictionary to a DataFrame
df = pd.DataFrame(data)

# Save or append data to CSV
file_name = 'hunters.csv'
if os.path.exists(file_name):
    df.to_csv(file_name, mode='a', header=False, index=False)
    print("New data has been appended to hunters.csv")
else:
    df.to_csv(file_name, mode='w', header=True, index=False)
    print("Data has been saved to hunters.csv")

