let lastScrapedData = [];


function scrapeTableData() {
    let bugTagElements = document.querySelectorAll('td.mat-column-bugTag');
    let dateElements = document.querySelectorAll('td.mat-column-date');
    let hunterElements = document.querySelectorAll('td.mat-column-hunter .username');
    
    let data = [];
    if (bugTagElements.length === dateElements.length && dateElements.length === hunterElements.length) {
        for (let i = 0; i < bugTagElements.length; i++) {
            let bugTag = bugTagElements[i].textContent.trim();  
            let date = dateElements[i].textContent.trim();
            let hunter = hunterElements[i].textContent.trim(); 

            data.push({ bugTag, date, hunter });
        }


        const csvData = convertToCSV(data);

        downloadCSV(csvData);
    }
}


function convertToCSV(data) {
    let csv = 'BugTag,Date,Hunter\n';  


    data.forEach(item => {
        csv += `"${item.bugTag}","${item.date}","${item.hunter}"\n`;
    });

    return csv;
}

function downloadCSV(csvData) {
    const blob = new Blob([csvData], { type: 'text/csv' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'scraped_data.csv'; 
}

function checkForNewData() {
    let bugTagElements = document.querySelectorAll('td.mat-column-bugTag');
    let dateElements = document.querySelectorAll('td.mat-column-date');
    let hunterElements = document.querySelectorAll('td.mat-column-hunter .username');
    
    let data = [];

    if (bugTagElements.length === dateElements.length && dateElements.length === hunterElements.length) {
        for (let i = 0; i < bugTagElements.length; i++) {
            let bugTag = bugTagElements[i].textContent.trim();  
            let date = dateElements[i].textContent.trim();
            let hunter = hunterElements[i].textContent.trim();  

            data.push({ bugTag, date, hunter });
        }
        if (JSON.stringify(data) !== JSON.stringify(lastScrapedData) && data.length > 0) {
            lastScrapedData = [...data]; 
            const csvData = convertToCSV(data);  
            downloadCSV(csvData);  
        }
    }
}
setInterval(checkForNewData, 5000);
