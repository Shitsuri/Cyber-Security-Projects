import requests
import base64
import pytesseract
import cv2
import re
import time


pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
url = "http://challenge01.root-me.org/programmation/ch8/"
headers = {"User-Agent": "Mozilla/5.0"}

start_time = time.time()  
response = requests.get(url, headers=headers)
html = response.text

match = re.search(r'data:image/png;base64,(.*?)"', html)
if not match:
    print("[-] CAPTCHA not found!")
    exit()
    
captcha_base64 = match.group(1)
captcha_data = base64.b64decode(captcha_base64)
with open("captcha.png", "wb") as file:
    file.write(captcha_data)


image = cv2.imread("captcha.png", cv2.IMREAD_GRAYSCALE)
_, thresh_image = cv2.threshold(image, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
captcha_text = pytesseract.image_to_string(thresh_image, config="--psm 6")
captcha_text = re.sub(r'\W+', '', captcha_text) 
print(f"[+] Extracted CAPTCHA: {captcha_text}")


data = {"cametu": captcha_text}
response = requests.post(url, headers=headers, data=data)

if "Failed" not in response.text:
    print("[✔] CAPTCHA Solved!")
    print(f"Challenge completed in {time.time() - start_time:.2f} seconds!")
else:
    print("[-] CAPTCHA Failed, retrying...")

